import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchServiceData } from "../Redux/Slice/ServiceSlice";
import { useQuery } from "@tanstack/react-query";

import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import Grid from "@mui/material/Grid";
import Container from '@mui/material/Container';
import ReactCardFlip from 'react-card-flip';
import { Link } from "react-router-dom";
import Layout from "../Layout/Layout";
import { RotatingLines } from "react-loader-spinner";

const Service = ({ withLayout = true }) => {
  
  const dispatch = useDispatch();
  const user = useSelector((state) => state?.auth.user);
  const { Logouttoggle, userName } = useSelector((state) => state.user);
  const isLoggedIn=localStorage.getItem('token')
  const fetchSerice = async () => {
    const response = await dispatch(fetchServiceData());
    return response?.payload.data;
  };
  const { data: serviceData, isLoading } = useQuery({
    queryKey: ["service"],
    queryFn: fetchSerice,
  });

  const [isFlipped, setIsFlipped] = useState({});

  const handleFlip = (index) => {
    setIsFlipped((prevState) => ({ ...prevState, [index]: !prevState[index] }));
  };

  console.log(serviceData);
  
  const serviceContent=(
    <Container>
    <Typography variant="h4" sx={{ display: 'flex', justifyContent: 'center', color: 'red' }}>
     Our Services
   </Typography>
   <Typography variant="h2" sx={{ display: 'flex', justifyContent: 'center', color: 'black' }}>
    Information about Our Services
   </Typography>
 <Grid container spacing={2}>
   {serviceData?.map((data, index) => (
     <Grid item xs={12} md={4} xl={4} key={data._id}>
       <ReactCardFlip isFlipped={isFlipped[index]} flipDirection="horizontal">
         <Card sx={{ maxWidth: 345 }} >
           <CardMedia
             component="img"
             alt={data.service_name}
             height="140"
             image={`${process.env.REACT_APP_BASE_URL}${data.image}`}
           />
           <CardContent>
             <Typography gutterBottom variant="h5" component="div">
               {data.service_name}
             </Typography>
             <Typography variant="body2" color="text.secondary">
               {data.service_description.slice(0, 100)}...
             </Typography>
           </CardContent>
           <CardActions>
             <Button size="small" onClick={() => handleFlip(index)} variant="contained">Trainer Info</Button>
             <Button size="small" variant="contained" ><Link to={`/serviceDetail/${data._id}`} style={{textDecoration:'none',color:'white'}}>Details</Link></Button>
           {
            isLoggedIn &&  <Button size="small" variant="contained" ><Link to={`/bookService/${user._id}`} style={{textDecoration:'none',color:'white'}}>Book</Link></Button>
           }
           </CardActions>
         </Card>

         <Card sx={{ maxWidth: 345 }}>
         <CardMedia
             component="img"
             alt={data.trainer_details.name}
             height="140"
             image={`${process.env.REACT_APP_BASE_URL}${data.trainer_details[0].image}`}
             style={{objectFit:'fill'}}
           />
           <CardContent>
             <Typography gutterBottom variant="h5" component="div">
             {data.trainer_details[0].name}
             </Typography>
             <Typography variant="body2" color="text.secondary">
               {data.trainer_details[0].experience}
             </Typography>
             <Typography variant="h6" color="text.secondary">
             {data.trainer_details[0].speciality}
             </Typography>
           </CardContent>
           <CardActions>
             <Button size="small" onClick={() => handleFlip(index)} variant="contained">Back</Button>
           </CardActions>
         </Card>
       </ReactCardFlip>
     </Grid>
   ))}
 </Grid>
</Container>
  )
  if (withLayout) {
    return (
      <Layout>
        {isLoading &&
        <>
         <div
              style={{
                display: "grid",
                placeItems: "center",
                height: "100vh",
                width: "100vw",
              }}
            >
              <RotatingLines
                visible={true}
                height="96"
                width="96"
                color="blue"
                strokeColor="blue"
                strokeWidth="5"
                animationDuration="0.75"
                ariaLabel="rotating-lines-loading"
                wrapperStyle={{}}
                wrapperClass=""
              />
            </div>
        </>
        }
        { serviceContent}
      </Layout>
    );
  } else {
    return serviceContent;
  }
};

export default Service;
