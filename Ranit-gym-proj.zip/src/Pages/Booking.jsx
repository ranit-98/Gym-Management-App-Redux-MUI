import React from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  Typography,
  Grid,
  Button,
  Divider,
  Container,
  Box,
} from '@mui/material';
import { styled } from '@mui/system';
import Layout from '../Layout/Layout';
import { useParams } from 'react-router-dom';
import { fetchBookingData } from '../Redux/Slice/BookingSlice';
import { useQuery } from '@tanstack/react-query';
import { useDispatch } from 'react-redux';

const StyledContainer = styled(Container)(({ theme }) => ({
  flexGrow: 1,
  padding: theme.spacing(2),
}));

const StyledCard = styled(Card)(({ theme }) => ({
  margin: theme.spacing(2),
}));

const Booking = () => {
    const {id}=useParams()
    const dispatch=useDispatch()
    const fetchBooking=async (id)=>{
        const response=await dispatch(fetchBookingData(id))
        return response.payload.result[0]
    }
    const {data}=useQuery({
        queryKey:['booking'],
        queryFn:()=> fetchBooking(id)
    })
    console.log(data);
  return (
    <Layout>
    <StyledContainer>
      <Typography variant="h4" align="center" gutterBottom>
        Booking Details
      </Typography>
      <Grid container spacing={3}>
        {/* {data?.map((booking) => (
          <Grid item xs={12} sm={6} md={4} key={booking._id}>
            <StyledCard>
              <CardHeader title={booking.serviceId.service_name} />
              <Divider />
              <CardContent>
                <Typography variant="subtitle1">Name: {booking.name}</Typography>
                <Typography variant="subtitle1">Email: {booking.email}</Typography>
                <Typography variant="subtitle1">Scheme: {booking.scheme}</Typography>
                <Typography variant="subtitle1">Price: {booking.price}</Typography>
                <Typography variant="subtitle1">
                  Status: {booking.isPending ? 'Pending' : 'Confirmed'}
                </Typography>
              </CardContent>
              <Box display="flex" justifyContent="center" padding={2}>
                <Button variant="contained" color="primary">
                  View Details
                </Button>
              </Box>
            </StyledCard>
          </Grid>
        ))} */}
      </Grid>
    </StyledContainer>
    </Layout>
  );
};

export default Booking;
