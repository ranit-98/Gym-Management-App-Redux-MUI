// UserDetails.js
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { check_token } from '../Redux/Slice/AuthSlice';

const UserDetails = () => {
  // Access user data from the Redux store
  const dispatch = useDispatch();
  const user = useSelector((state) => state.auth.user);
  const userName = useSelector((state) => state.auth.userName);
  

  useEffect(() => {
    // Check if the token exists and fetch user details
    dispatch(check_token());
   
  }, [dispatch]);

//   if (!userName) {
//     return <div>Please log in to see user details.</div>;
//   }
console.log('ohlhl',user._id);
  return (
    <div>
      <h2>User Details</h2>
      <p>Name: {user.name}</p>
      <p>Email: {user.email}</p>
      {/* Add other user details as needed */}
    </div>
  );
};

export default UserDetails;

