import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchGetBlogData } from "../Redux/Slice/BlogSlice";
import { useQuery } from "@tanstack/react-query";

import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Grid from "@mui/material/Grid";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Layout from "../Layout/Layout";
import { Link } from "react-router-dom";
import { RotatingLines } from "react-loader-spinner";
const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: "center",
  color: theme.palette.text.secondary,
}));
const Blogs = () => {
  const dispatch = useDispatch();

  const fetchBlogs = async () => {
    const response = await dispatch(fetchGetBlogData());
    return response.payload.data;
  };

  const { data: blogData,isLoading } = useQuery({
    queryKey: ["blogsData"],
    queryFn: fetchBlogs,
  });

  console.log(blogData);
  return (
    <>
    <Layout>
      {isLoading && <>
        <div
              style={{
                display: "grid",
                placeItems: "center",
                height: "100vh",
                width: "100vw",
              }}
            >
              <RotatingLines
                visible={true}
                height="96"
                width="96"
                color="blue"
                strokeColor="blue"
                strokeWidth="5"
                animationDuration="0.75"
                ariaLabel="rotating-lines-loading"
                wrapperStyle={{}}
                wrapperClass=""
              />
            </div>
      </>}
     { !isLoading && 
     <Box sx={{ flexGrow: 1 }} style={{margin:'1rem'}}>
        <Grid container spacing={2}>
          {blogData?.map((data) => {
            return (
              <>
                <Grid item xs={12} md={6}>
                  
                    <Card sx={{ maxWidth: 750,backgroundColor:'black',color:'white' }} data-aos="zoom-in">
                      <CardMedia
                      component="img"
                        sx={{ height: 400 }}
                        image={`${process.env.REACT_APP_BASE_URL}${data.image}`}
                        title="green iguana"
                        style={{objectFit:'fill'}}
                      />
                      <CardContent>
                        <Typography gutterBottom variant="h4" component="div" style={{color:'red'}}>
                          {data.title}
                        </Typography>
                        <Typography gutterBottom variant="h5" component="div">
                          {data.subtitle}
                        </Typography>
                        <Typography variant="body2" color="text.secondary" style={{color:'white'}}>
                         {data.content}
                        </Typography>
                      </CardContent>
                      <CardActions>
                        <Button size="small" variant='contained' style={{backgroundColor:'red',marginLeft:'40%',marginButtom:'10%'}}>
                        <Link to={`/blogDetail/${data._id}`} style={{textDecoration:'none',color:'white'}}>               
                             Details
                        </Link>
                        </Button>
                        
                      </CardActions>
                    </Card>
                  
                </Grid>
              </>
            );
          })}
        </Grid>
      </Box>}
      </Layout>
    </>
  );
};

export default Blogs;
