import React from "react";
import { useDispatch } from "react-redux";
import { fetchBlogDetails } from "../Redux/Slice/BlogDetails";
import { useQuery } from "@tanstack/react-query";
import Layout from "../Layout/Layout";
import { useParams } from "react-router-dom";
import { CardContent, CardMedia, Typography } from "@mui/material";
import { RotatingLines } from "react-loader-spinner";

const BlogDetails = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const fetchBlogDetailsData = async (id) => {
    const response = await dispatch(fetchBlogDetails(id));
    return response.payload.data;
  };

  const { data: blogDetailData, isLoading } = useQuery({
    queryKey: ["blogDetail"],
    queryFn: () => fetchBlogDetailsData(id),
  });
  console.log(blogDetailData);
  return (
    <>
      <Layout>
        {isLoading && 
        <>
         <div
              style={{
                display: "grid",
                placeItems: "center",
                height: "100vh",
                width: "100vw",
              }}
            >
              <RotatingLines
                visible={true}
                height="96"
                width="96"
                color="blue"
                strokeColor="blue"
                strokeWidth="5"
                animationDuration="0.75"
                ariaLabel="rotating-lines-loading"
                wrapperStyle={{}}
                wrapperClass=""
              />
            </div>
        </>
        }
        {!isLoading && (
          <>
            <CardMedia
              component="img"
              sx={{ height: 400 }}
              image={`${process.env.REACT_APP_BASE_URL}${blogDetailData.image}`}
              title="green iguana"
              style={{ objectFit: "fill" }}
            />
            <CardContent>
              <Typography
                gutterBottom
                variant="h4"
                component="div"
                style={{ color: "red" }}
              >
                {blogDetailData.title}
              </Typography>
              <Typography gutterBottom variant="h5" component="div">
                {blogDetailData.subtitle}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {blogDetailData.content}
              </Typography>
            </CardContent>
          </>
        )}
      </Layout>
    </>
  );
};

export default BlogDetails;
